declare module 'rehype-highlight';
