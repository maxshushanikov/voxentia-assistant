import { apiFetch } from './client';
import type {
  ChatHistoryResponse,
  ChatRequestBody,
  ChatResponseBody,
  DocumentUploadResponse,
  TranscribeResponseBody,
} from './types';

export interface PluginListItem {
  id: string;
  name: string;
  version: string;
  status: string;
  enabled: boolean;
  description?: string;
  intents?: string[];
  capabilities?: string[];
  triggers?: string[];
  permissions?: string[];
}

export function postChat(body: ChatRequestBody) {
  return apiFetch<ChatResponseBody>('/api/chat', {
    method: 'POST',
    body: JSON.stringify(body),
  });
}

export function postMessageFeedback(sessionId: string, messageId: number, feedback: 'like' | 'dislike' | null) {
  return apiFetch<{ session_id: string; message_id: number; feedback: 'like' | 'dislike' | null }>(
    '/api/chat/feedback',
    {
      method: 'POST',
      body: JSON.stringify({ session_id: sessionId, message_id: messageId, feedback }),
    },
  );
}

export function getChatHistory(sessionId: string) {
  return apiFetch<ChatHistoryResponse>(
    `/api/chat/history?session_id=${encodeURIComponent(sessionId)}`,
  );
}

export function postTranscribe(formData: FormData) {
  return apiFetch<TranscribeResponseBody>('/api/transcribe', {
    method: 'POST',
    body: formData,
    headers: {},
  });
}

export function getSessions() {
  return apiFetch<{ sessions: { session_id: string; title: string; timestamp: string }[] }>(
    '/api/sessions',
  );
}

export function deleteSession(sessionId: string) {
  return apiFetch<{ message: string; deleted_messages: number }>(
    `/api/sessions/${encodeURIComponent(sessionId)}`,
    { method: 'DELETE' },
  );
}

export function deleteAllSessions() {
  return apiFetch<{ message: string; deleted_messages: number }>('/api/sessions', {
    method: 'DELETE',
  });
}

export function createSession() {
  return apiFetch<{ session_id: string }>('/api/v1/sessions/new', { method: 'POST' });
}

export function forkSession(sessionId: string, messageId: number) {
  return apiFetch<import('./types').ForkSessionResponse>('/api/v1/sessions/fork', {
    method: 'POST',
    body: JSON.stringify({ session_id: sessionId, message_id: messageId }),
  });
}

export function listModels() {
  return apiFetch<{ models: { name: string }[]; default: string }>('/api/v1/models');
}

export function listPlugins() {
  return apiFetch<{
    plugins: {
      id: string;
      name: string;
      version: string;
      status: string;
      enabled: boolean;
      description?: string;
      intents?: string[];
      capabilities?: string[];
      triggers?: string[];
      permissions?: string[];
    }[];
  }>('/api/v1/plugins/list');
}

export function uploadDocument(formData: FormData) {
  return apiFetch<DocumentUploadResponse>('/api/documents/upload', {
    method: 'POST',
    body: formData,
    headers: {},
  });
}
