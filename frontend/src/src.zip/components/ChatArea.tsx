import { useRef, useEffect, useState } from 'react';
import { Sparkles, MessageSquare, Zap, Shield, Copy, Pencil, RefreshCw, Cpu, ThumbsUp, ThumbsDown, Trash2 } from 'lucide-react';
import MarkdownMessage from './MarkdownMessage';
import type { ReactNode } from 'react';

import { useTranslation } from '../i18n/context';
import { cn } from '../utils/cn';
import type { Message } from '../types';
import { postMessageFeedback } from '../api/chat';

function estimateTokenCount(messages: { content: string }[]) {
  return messages.reduce((sum, message) => {
    const length = message.content.trim().length;
    return sum + Math.max(1, Math.round(length / 4));
  }, 0);
}

interface ChatAreaProps {
  sessionId: string;
  messages: Message[];
  isThinking: boolean;
  onTileClick?: (prompt: string) => void;
  onEditMessage?: (id: string, content: string) => void;
  onRegenerate?: (id: string) => void;
  onDeleteMessage?: (id: string) => void;
}

export default function ChatArea({ sessionId, messages, isThinking, onTileClick, onEditMessage, onRegenerate, onDeleteMessage }: ChatAreaProps) {
  const { t } = useTranslation();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const hasStreaming = messages.some((m) => m.streaming);
  const [feedbackState, setFeedbackState] = useState<Partial<Record<string, 'like' | 'dislike'>>>({});

  const tokenCount = messages.length > 0 ? estimateTokenCount(messages) : null;
  const tokenBudget = 8192;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    const mapped: Partial<Record<string, 'like' | 'dislike'>> = {};
    messages.forEach((message) => {
      if (message.feedback) {
        const key = message.dbId ? message.dbId.toString() : message.id;
        mapped[key] = message.feedback;
      }
    });
    setTimeout(() => {
      setFeedbackState(mapped);
    }, 0);
  }, [messages]);

  const toggleFeedback = (message: Message, value: 'like' | 'dislike') => {
    const messageKey = message.dbId ? message.dbId.toString() : message.id;
    const nextValue = feedbackState[messageKey] === value ? undefined : value;

    setFeedbackState((prev) => ({
      ...prev,
      [messageKey]: nextValue,
    }));

    if (message.dbId) {
      void postMessageFeedback(sessionId, message.dbId, nextValue ?? null).catch((error) => {
        console.error('Failed to persist message feedback', error);
      });
    }
  };

  if (messages.length === 0 || (messages.length === 1 && messages[0].id === 'greeting')) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-[var(--bg-primary)]">
        <div className="w-16 h-16 bg-[var(--accent)]/10 rounded-full flex items-center justify-center mb-8 animate-pulse">
          <Sparkles className="w-8 h-8 text-[var(--accent)]" />
        </div>
        <h1 className="text-4xl font-light text-[var(--text-primary)] mb-4 tracking-tight text-center">
          {t.greeting.split(',')[0]}
        </h1>
        <p className="text-[var(--text-secondary)] text-center max-w-md mb-12">{t.chat_welcomeSubtitle}</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-2xl">
          <WelcomeTile
            icon={<Zap className="w-4 h-4 text-[var(--warning)]" />}
            title={t.chat_quickAnalysis}
            desc={t.chat_quickAnalysisDesc}
            onClick={() => onTileClick?.((t as unknown as Record<string, string>).chat_quickAnalysisPrompt || t.chat_quickAnalysis)}
          />
          <WelcomeTile
            icon={<MessageSquare className="w-4 h-4 text-[var(--accent)]" />}
            title={t.chat_creativeWriting}
            desc={t.chat_creativeWritingDesc}
            onClick={() => onTileClick?.((t as unknown as Record<string, string>).chat_creativeWritingPrompt || t.chat_creativeWriting)}
          />
          <WelcomeTile
            icon={<Shield className="w-4 h-4 text-[var(--success)]" />}
            title={t.chat_privateSecure}
            desc={t.chat_privateSecureDesc}
            onClick={() => onTileClick?.((t as unknown as Record<string, string>).chat_privateSecurePrompt || t.chat_privateSecure)}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar relative bg-[rgba(10,15,28,0.88)] backdrop-blur-[14px]">
      {tokenCount !== null && (
        <div className="sticky top-0 float-right z-30 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[rgba(56,189,248,0.12)] border border-[rgba(56,189,248,0.24)] backdrop-blur-lg shadow-sm mr-2 select-none">
          <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent)] animate-pulse" />
          <span className="text-[9px] font-extrabold text-[var(--accent)] uppercase tracking-wider">
            {tokenCount} / {tokenBudget} Tokens
          </span>
        </div>
      )}
      <div className="absolute inset-x-8 bottom-8 h-px bg-[rgba(255,255,255,0.06)]" />
      <div className="max-w-4xl mx-auto w-full">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={cn('flex flex-col mb-8 animate-soft-slide-up', msg.role === 'user' ? 'items-end' : 'items-start')}
          >
            <div
              className={cn(
                'max-w-[85%] rounded-[24px] p-5 text-[15px] leading-relaxed relative group transition-all duration-200',
                msg.role === 'user'
                  ? 'rounded-tr-none bg-gradient-to-tr from-[rgba(41,121,255,0.18)] via-[rgba(41,121,255,0.06)] to-[rgba(15,23,42,0.85)] border border-[var(--accent)]/30 text-[var(--text-primary)] shadow-[0_12px_40px_rgba(41,121,255,0.15)]'
                  : 'rounded-tl-none bg-[rgba(255,255,255,0.03)] dark:bg-[rgba(255,255,255,0.02)] border border-[rgba(255,255,255,0.08)] text-[var(--text-primary)] shadow-[0_12px_36px_rgba(0,0,0,0.18)] backdrop-blur-md',
              )}
            >
              {msg.role === 'assistant' && (
                <div className="absolute -right-8 top-2 flex flex-col space-y-1 opacity-0 group-hover:opacity-100 transition-all">
                  <button
                    onClick={() => navigator.clipboard.writeText(msg.content)}
                    className="p-1.5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10"
                    title="Copy message"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onRegenerate?.(msg.id)}
                    className="p-1.5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10"
                    title="Antwort neu generieren"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteMessage?.(msg.id)}
                    className="p-1.5 text-[var(--text-secondary)] hover:text-[var(--danger)] rounded-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10"
                    title="Antwort löschen"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
              {msg.role === 'user' && (
                <div className="absolute -left-8 top-2 flex flex-col space-y-1 opacity-0 group-hover:opacity-100 transition-all">
                  <button
                    onClick={() => onEditMessage?.(msg.id, msg.content)}
                    className="p-1.5 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10"
                    title="Edit message"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteMessage?.(msg.id)}
                    className="p-1.5 text-[var(--text-secondary)] hover:text-[var(--danger)] rounded-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10"
                    title="Nachricht löschen"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
              {msg.comparison ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 min-w-[60vw]">
                  <div className="flex flex-col border-r border-black/10 dark:border-white/10 pr-6 last:border-r-0 last:pr-0">
                    <div className="flex items-center space-x-2 mb-3 pb-2 border-b border-black/5 dark:border-b-white/5">
                      <Cpu className="w-3.5 h-3.5 text-[var(--accent)]" />
                      <span className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider">
                        {msg.comparison.modelA}
                      </span>
                      {msg.comparison.streamingA && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent)] animate-ping" />
                      )}
                      {msg.comparison.latencyA != null && !msg.comparison.streamingA && (
                        <span className="text-[10px] text-[var(--text-secondary)] ml-auto">
                          {msg.comparison.latencyA} ms
                        </span>
                      )}
                    </div>
                    <div className="flex-1 overflow-x-auto min-w-0">
                      <MarkdownMessage content={msg.comparison.contentA} />
                    </div>
                  </div>

                  <div className="flex flex-col">
                    <div className="flex items-center space-x-2 mb-3 pb-2 border-b border-black/5 dark:border-b-white/5">
                      <Cpu className="w-3.5 h-3.5 text-[var(--warning)]" />
                      <span className="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider">
                        {msg.comparison.modelB}
                      </span>
                      {msg.comparison.streamingB && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[var(--warning)] animate-ping" />
                      )}
                      {msg.comparison.latencyB != null && !msg.comparison.streamingB && (
                        <span className="text-[10px] text-[var(--text-secondary)] ml-auto">
                          {msg.comparison.latencyB} ms
                        </span>
                      )}
                    </div>
                    <div className="flex-1 overflow-x-auto min-w-0">
                      <MarkdownMessage content={msg.comparison.contentB} />
                    </div>
                  </div>
                </div>
              ) : (
                <MarkdownMessage content={msg.content} />
              )}
              {msg.role === 'assistant' && msg.intentConfidence != null && msg.intentConfidence < 0.6 && (
                <p className="mt-2 text-[11px] text-[var(--warning)] italic">
                  Ich bin mir bei der Interpretation unsicher — meintest du das so?
                </p>
              )}
              {msg.role === 'assistant' && msg.ragSources && msg.ragSources.length > 0 && (
                <div className="mt-3 pt-2 border-t border-black/5 dark:border-white/5 space-y-1">
                  {msg.ragSources.map((src, i) => (
                    <p key={`${src.filename}-${src.chunk_index}-${i}`} className="text-[11px] text-[var(--text-secondary)]">
                      📄 {src.filename}
                      {src.page != null ? `, Seite ${src.page}` : ''}
                      {' '}
                      <span className="opacity-60">({Math.round(src.score * 100)}%)</span>
                    </p>
                  ))}
                </div>
              )}
              {msg.role === 'assistant' && (
                <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-[var(--text-secondary)]">
                  <span className="font-semibold uppercase tracking-[0.2em]">Feedback</span>
                  <button
                    type="button"
                    onClick={() => toggleFeedback(msg, 'like')}
                    aria-pressed={feedbackState[msg.dbId?.toString() ?? msg.id] === 'like'}
                    className={cn(
                      'inline-flex items-center gap-1 rounded-full border px-2.5 py-1 transition-colors',
                      feedbackState[msg.dbId?.toString() ?? msg.id] === 'like'
                        ? 'bg-[var(--accent)]/15 border-[var(--accent)] text-[var(--text-primary)]'
                        : 'bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-[var(--text-secondary)] hover:bg-black/10 dark:hover:bg-white/10',
                    )}
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    {(t as unknown as Record<string, string>).common_like || 'Helpful'}
                  </button>
                  <button
                    type="button"
                    onClick={() => toggleFeedback(msg, 'dislike')}
                    aria-pressed={feedbackState[msg.dbId?.toString() ?? msg.id] === 'dislike'}
                    className={cn(
                      'inline-flex items-center gap-1 rounded-full border px-2.5 py-1 transition-colors',
                      feedbackState[msg.dbId?.toString() ?? msg.id] === 'dislike'
                        ? 'bg-[var(--danger)]/15 border-[var(--danger)] text-[var(--text-primary)]'
                        : 'bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-[var(--text-secondary)] hover:bg-black/10 dark:hover:bg-white/10',
                    )}
                  >
                    <ThumbsDown className="w-3.5 h-3.5" />
                    {(t as unknown as Record<string, string>).common_dislike || 'Needs improvement'}
                  </button>
                </div>
              )}
              {msg.timestamp && (
                <div className={cn("text-[10px] mt-2 opacity-40 select-none", msg.role === 'user' ? "text-right" : "text-left")}>
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              )}
              {msg.streaming && (
                <span
                  className="inline-block w-0.5 h-4 ml-0.5 align-middle bg-[var(--accent)] animate-pulse"
                  aria-hidden
                />
              )}
            </div>
          </div>
        ))}
        {isThinking && !hasStreaming && (
          <div className="flex justify-start">
            <div className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-full px-4 py-2 flex space-x-1.5 items-center" role="status" aria-live="polite">
              <div className="w-1.5 h-1.5 bg-[var(--accent)] rounded-full animate-bounce" />
              <div className="w-1.5 h-1.5 bg-[var(--accent)] rounded-full animate-bounce [animation-delay:0.2s]" />
              <div className="w-1.5 h-1.5 bg-[var(--accent)] rounded-full animate-bounce [animation-delay:0.4s]" />
              <span className="text-xs text-[var(--text-secondary)] ml-2">{t.thinking}</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
}

function WelcomeTile({ icon, title, desc, onClick }: { icon: ReactNode; title: string; desc: string, onClick?: () => void }) {
  return (
    <div onClick={onClick} className="glass-card rounded-[8px] p-4 border border-black/5 dark:border-white/5 hover:border-[var(--accent)]/30 transition-all cursor-pointer group">
      <div className="flex items-center space-x-2 mb-2">
        {icon}
        <h3 className="text-sm font-medium text-[var(--text-primary)] group-hover:text-[var(--accent)] transition-colors">
          {title}
        </h3>
      </div>
      <p className="text-xs text-[var(--text-secondary)]">{desc}</p>
    </div>
  );
}
